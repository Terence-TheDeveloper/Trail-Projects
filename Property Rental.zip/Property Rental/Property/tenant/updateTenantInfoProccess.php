<?php include ('header.php'); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <title>Update</title>
    <meta charset="utf-8">
    <style>
    </style>
  </head>
<?php
$id = $_SESSION['username'];
$query= "SELECT * FROM tenant where tenantUsername='$id'";
$result= mysqli_query($conn,$query);
$row = mysqli_fetch_assoc($result);

?>
  <body>
    <center>
      <h1>UPDATE tenant INFO</h1>

      <form action="" method="POST">
        <label>Username</label>
        <input type="text" name="tenantUsername" placeholder="<?php echo $row['tenantUsername']; ?>" value="<?php echo $row['tenantUsername']; ?>" readonly/><br/>
        <label>Firstname</label>
        <input type="text" name="tenantFname" placeholder="<?php echo $row['tenantFname']; ?>" value="<?php echo $row['tenantFname']; ?>" /><br/>
        <label>Lastname</label>
        <input type="text" name="tenantLname" placeholder="<?php echo $row['tenantLname']; ?>" value="<?php echo $row['tenantLname']; ?>" /><br/>
        <label>Password</label>
        <input type="password" name="tenantPassword" placeholder="<?php echo $row['tenantPassword']; ?>"  value="<?php echo $row['tenantPassword']; ?>" readonly/><br/>
        <label>Email</label>
        <input type="email" name="tenantEmail" placeholder="<?php echo $row['tenantEmail']; ?>" value="<?php echo $row['tenantEmail']; ?>" /><br/>

      <input type="submit" name="update" value="Update Profile"/>

      <p> <a href="tenantProfile.php" style="color: red;">Cancel</a> </p>
    </center>
  </body>
</html>

<?php
 if (isset($_POST['update']))
 {
   $username = $_POST['tenantUsername'];
   $firstanme = $_POST['tenantFname'];
   $lastname = $_POST['tenantLname'];
   $password = $_POST['tenantPassword'];
   $email = $_POST['tenantEmail'];

   $query = "UPDATE tenant SET tenantFname='$firstanme',
   tenantLname='$lastname', tenantPassword='$password',tenantEmail='$email'
   WHERE tenantUsername= '$id'";

   $query_run = mysqli_query($conn,$query) or die(mysqli_error($conn));

   if ($query_run) {
     echo '<script type="text/javaScript"> alert("Data Updated") </script>';
     header('location: tenantProfile.php');
   }
   else
   {
      echo '<script type="text/javaScript"> alert("Data Not Updated") </script>';
   }

 }
 ?>

<?php
session_start();
include '../connect.php';
if (isset($_GET['tpropId'])) {
$tenantPropId=$_GET['tpropId'];
}
$res=mysqli_query($conn, "SELECT tp.*, t.* FROM tenantproperty tp
  JOIN tenant t
    On tp.tenantUsername = t.tenantUsername
	WHERE tp.tenantPropId ='$tenantPropId'");

$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Invoice</title>
        <link rel="stylesheet" type="text/css" href="assets/invoice.css">

    </head>
    <body>
        <div class="invoice-box">
            <table cellpadding="0" cellspacing="0">
                <tr class="top">
                    <td colspan="2">
                        <table>
                            <tr>
                                <td class="title">
                                    <img src="img/logo2.png" style="width:100%; max-width:200px;">
                                </td>

                                <td>
                                    Invoice #: <?php echo $userRow['tenantPropId'];?><br>
                                    Created: <?php echo date("d-m-Y");?><br>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>

                <tr class="information">
                    <td colspan="2">
                        <table>
                            <tr>
                                <td><?php echo $userRow['tenantUsername'];?><br>
                                    <?php echo $userRow['tenantFname'];?> <?php echo $userRow['tenantLname'];?><br>
                                    <?php echo $userRow['tenantEmail'];?>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>



                <tr class="heading">
                    <td>
                        Rental Details
                    </td>

                    <td>
                        #
                    </td>
                </tr>

                <tr class="item">
                    <td>
                        Tenant Property ID
                    </td>

                    <td>
                       <?php echo $userRow['tenantPropId'];?>
                    </td>
                </tr>

                <tr class="item">
                    <td>
                        Property ID
                    </td>

                    <td>
                        <?php echo $userRow['propertyNo'];?>
                    </td>
                </tr>

                <tr class="item">
                    <td>
                        Occupation Date
                    </td>

                    <td>
                        <?php echo $userRow['tpOccupationDate'];?>
                    </td>
                </tr>


                 <tr class="item">
                    <td>
                        Leave Date
                    </td>

                    <td>
                        <?php echo $userRow['tpLeaveDate'];?>
                    </td>
                </tr>

                 <tr class="item">
                    <td>
                        Rental Price
                    </td>

                    <td>
                        <?php echo "R " .$userRow['tpRentalPrice'];?>
                    </td>
                </tr>
            </table>
            <div class="print">
              <br>
            <button onclick="myFunction()">Print</button>
              </br>
            </div>
        </div>

<script>
function myFunction() {
    window.print();
}
</script>
    </body>
</html>

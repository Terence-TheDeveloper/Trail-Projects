<?php include ('header.php');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <title>Update</title>
    <meta charset="utf-8">
<style>
</style>
  </head>
<?php
$id = $_SESSION['username'];
$query= "SELECT * FROM tenant where tenantUsername='$id'";
$result= mysqli_query($conn,$query);
$row = mysqli_fetch_assoc($result);

?>
  <body>
    <center>
      <h1>UPDATE Tenant INFO</h1>

      <form action="" method="POST">
        <label>Username</label>
        <input type="text" name="tenantUsername" placeholder="<?php echo $row['tenantUsername']; ?>" value="<?php echo $row['tenantUsername']; ?>" readonly/><br/>
        <label>Firstname</label>
        <input type="text" name="tenantFname" placeholder="<?php echo $row['tenantFname']; ?>" value="<?php echo $row['tenantFname']; ?>" readonly/><br/>
        <label>Lastname</label>
        <input type="text" name="tenantLname" placeholder="<?php echo $row['tenantLname']; ?>" value="<?php echo $row['tenantLname']; ?>" readonly/><br/>
        <label>Password</label>
        <input type="password" name="tenantPassword" placeholder="<?php echo $row['tenantPassword']; ?>"  value="<?php echo $row['tenantPassword']; ?>" readonly/><br/>
        <label>Email</label>
        <input type="email" name="tenantEmail" placeholder="<?php echo $row['tenantEmail']; ?>" value="<?php echo $row['tenantEmail']; ?>" readonly/><br/>

      <input type="submit" name="update" value="Edit Profile"/>
      <p> <a href="index.php" style="color: red;">Home</a> </p>
    </center>
  </body>
</html>
<?php
 if (isset($_POST['update']))
 {
     header('location: updateTenantInfoProccess.php');

 }
 ?>

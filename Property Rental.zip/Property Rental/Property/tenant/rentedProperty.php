<?php
include ('header.php');
$session=$_SESSION['username'];

$res=mysqli_query($conn, "SELECT tp.*, t.* FROM tenantproperty tp
  JOIN tenant t
    On tp.tenantUsername = t.tenantUsername
	WHERE tp.tenantUsername ='$session'");
	$userRow=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Properties Rented</title>
	</head>
	<body>
<?php

echo "<div class='container'>";
echo "<div class='row'>";
echo "<div class='page-header'>";
echo "<h1>Username: ".$session."</h1>";
;
echo "</div>";
echo "<div class='panel panel-primary'>";
echo "<div class='panel-heading'>List of Properties</div>";
echo "<div class='panel-body'>";
echo "<table class='table table-hover'>";
echo "<thead>";
echo "<tr>";
echo "<th>Property Number</th>";
echo "<th>Firstname </th>";
echo "<th>Lastname </th>";
echo "<th>Occupation Date</th>";
echo "<th>Leave Date </th>";
echo "<th>Price </th>";
echo "<th>Print </th>";
echo "</tr>";
echo "</thead>";
$res = mysqli_query($conn, "SELECT tp.*, t.* FROM tenantproperty tp
  JOIN tenant t
    On tp.tenantUsername = t.tenantUsername
	WHERE tp.tenantUsername ='$session'");

if (!$res) {
die("Error running $sql: " . mysqli_error());
}


while ($userRow = mysqli_fetch_array($res)) {
echo "<tbody>";
echo "<tr>";
echo "<td>" . $userRow['propertyNo'] . "</td>";
echo "<td>" . $userRow['tenantFname'] . "</td>";
echo "<td>" . $userRow['tenantLname'] . "</td>";
echo "<td>" . $userRow['tpOccupationDate'] . "</td>";
echo "<td>" . $userRow['tpLeaveDate'] . "</td>";
echo "<td>" . $userRow['tpRentalPrice'] . "</td>";
echo "<td><a href='invoice.php?tpropId=".$userRow['tenantPropId']."' target='_blank' ' >Print</a> </td>";
}

echo "</tr>";
echo "</tbody>";
echo "</table>";

?>
	</div>
</div>
</div>
</div>
</body>
</html>

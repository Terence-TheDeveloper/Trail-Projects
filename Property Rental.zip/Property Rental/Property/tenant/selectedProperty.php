<?php
include ('header.php');

$user_check_query = "SELECT * FROM property P, propertyDetails pD, provincelookup pL, citylookup cL, propertypicture pP, agent A
WHERE P.propertyNo = pD.propertyNo AND P.provinceId = pL.provinceId AND P.cityId = cL.cityId AND P.propertyNo = pP.propertyNo AND A.agentUsername = P.agentUsername AND P.propertyNo = '6'";

$result = mysqli_query($conn, $user_check_query);
$row = mysqli_fetch_assoc($result);

if (isset($_GET['back'])) {
  session_destroy();
  unset($_SESSION['username']);
  header("location: registration/login.php");
}
?>
<!DOCTYPE html>

<html>

  <head>

    <title> HTML Table to search data</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  </head>

<body>
  <br>
<div class="container" >
<div class="card-body-secondary">
    <img src="../img/<?= $row['imageProp']?>" class="card-img-top" style="height:300px; width:300px">
    <div class="card-img">
      <h6 style="margin-top:10px;" class="text-light bg-info text-center rounded p-1">
        <?= $row['agentUsername']; ?>
      </h6>
  </div>
</div>
  <p >
  <h3>
    Description :<br>
  </h3>
  <textarea class="container" > <?= $row['pdDescription'] ?> </textarea>
  </p>
  <h3>
  Property Price
  </h3>
  <h4 class="card-title text-danger" style="border: 1px solid #B0C4DE; padding: 20px;">Price
    : <?= number_format($row['pdPrice']); ?>
  </h4>
  <h3>
  Property Information
  </h3>
  <p style="border: 1px solid #B0C4DE; padding: 20px;">
    Bedrooms : <?= $row['pdBedroomCount']; ?><br>
    Bathrooms : <?= $row['pdBathroomCount']; ?><br>
    Garage : <?= $row['pdParkingNum']; ?><br>
    Pets Allowed : <?= $row['pdPetAllowed']; ?><br>
    Furnished : <?= $row['pdFurnished']; ?><br>
  </p>
  <h3>
  Contact to Lease property
  </h3>
  <p style="border: 1px solid #B0C4DE; padding: 20px;">
  Contact Agent: <br>
  <a href = "tel:<?= $row['agentCellPhone']; ?>"> Call Agent</a> <br>
  <a href = "mailto:<?= $row['agentEmail']; ?>"> Send Email</a>
  </p>
</div>
  </body>

 </html>

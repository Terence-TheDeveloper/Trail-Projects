<?php
include ('header.php');
if(isset($_POST['search']))
{

  $valueToSearch = $_POST['valueToSearch'];

  // search data in all table columns

  $query = "SELECT * FROM property P, propertyDetails pD, provincelookup pL, citylookup cL, propertypicture pP

  WHERE P.propertyNo = pD.propertyNo AND P.provinceId = pL.provinceId AND P.cityId = cL.cityId
  AND P.propertyNo = pP.propertyNo AND cL.cityName LIKE

  '%".$valueToSearch."%'";

  $search_result = $conn->query($query);
}
else {
  $query = "SELECT * FROM property P, propertyDetails pD, provincelookup pL, citylookup cL, propertypicture pP
  WHERE P.propertyNo = pD.propertyNo AND P.provinceId = pL.provinceId AND P.cityId = cL.cityId AND P.propertyNo = pP.propertyNo";

  $search_result = $conn->query($query);



}

if (isset($_POST['selectedProperty'])) {
  header('location: selectedProperty.php');
}


?>

<!DOCTYPE html>

<html>

<head>

  <title>Find Property</title>

</head>

<body>

  <br>
  <div class="container">
    <form class="form-inline" action="findProperty.php" method="post">

      <input type="text" class="form-control mb-2 mr-sm-2" name="valueToSearch" placeholder="Value To Search">

      <input type="submit" class="btn btn-primary mb-2" name="search" value="Search">

    </form>
    <br>
    <form action"findProperty.php" method="post">
      Apartment Type:
      <?php
      $propertyType= "SELECT DISTINCT propType FROM property ORDER BY propType";
      /* You can add order by clause to the sql statement if the names are to be displayed in alphabetical order */
      echo "<select name=provinceLookup value='propType'>Property Type</option>"; // list box select command

      foreach ($conn->query($propertyType) as $row){//Array or records stored in $row

        echo "<option> $row[propType]</option>";
        /* Option values are added by looping through the array */
      }
      echo "</select>";// Closing of list box

//Filter properties
      if(isset($_POST['submitFilter'])) {

        if(isset($_POST['provinceLookup'])) {
          $propType = $_POST["provinceLookup"];

          $query = "SELECT * FROM property P, propertyDetails pD, provincelookup pL, citylookup cL, propertypicture pP
          WHERE P.propertyNo = pD.propertyNo AND P.provinceId = pL.provinceId AND P.cityId = cL.cityId AND P.propertyNo = pP.propertyNo AND P.propType = '$propType'";

          $search_result = $conn->query($query);
        }
        if(isset($_POST['furnished'])) {
          $furnished = $_POST["furnished"];

          $query = "SELECT * FROM property P, propertyDetails pD, provincelookup pL, citylookup cL, propertypicture pP
          WHERE P.propertyNo = pD.propertyNo AND P.provinceId = pL.provinceId AND P.cityId = cL.cityId AND P.propertyNo = pP.propertyNo AND pD.pdFurnished = '$furnished'";

          $search_result = $conn->query($query);
        }
        if(isset($_POST['pet'])) {
          $pet = $_POST["pet"];

          $query = "SELECT * FROM property P, propertyDetails pD, provincelookup pL, citylookup cL, propertypicture pP
          WHERE P.propertyNo = pD.propertyNo AND P.provinceId = pL.provinceId AND P.cityId = cL.cityId AND P.propertyNo = pP.propertyNo AND pD.pdPetAllowed = '$pet'";

          $search_result = $conn->query($query);
        }
        if(isset($_POST['bedNum'])) {
          $bedNum = $_POST["bedNum"];

          $query = "SELECT * FROM property P, propertyDetails pD, provincelookup pL, citylookup cL, propertypicture pP
          WHERE P.propertyNo = pD.propertyNo AND P.provinceId = pL.provinceId AND P.cityId = cL.cityId AND P.propertyNo = pP.propertyNo AND pD.pdBedroomCount >= '$bedNum'";

          $search_result = $conn->query($query);
        }
        if(isset($_POST['bathNum'])) {
          $bathNum = $_POST["bathNum"];

          $query = "SELECT * FROM property P, propertyDetails pD, provincelookup pL, citylookup cL, propertypicture pP
          WHERE P.propertyNo = pD.propertyNo AND P.provinceId = pL.provinceId AND P.cityId = cL.cityId AND P.propertyNo = pP.propertyNo AND pD.pdBathroomCount >= '$bathNum'";

          $search_result = $conn->query($query);
        }

        if(isset($_POST['min']) && isset($_POST['max'])) {
          $min = $_POST["min"];
          $max = $_POST["max"];

          $query = "SELECT * FROM property P, propertyDetails pD, provincelookup pL, citylookup cL, propertypicture pP
          WHERE P.propertyNo = pD.propertyNo AND P.provinceId = pL.provinceId AND P.cityId = cL.cityId AND P.propertyNo = pP.propertyNo AND pD.pdPrice BETWEEN '$min' AND '$max'";

          $search_result = $conn->query($query);
          }

      }
      ?>
      Furnished:
      <select name=furnished value='furnished'>
        <option >Yes</option>
        <option >No</option>
      </select>
      Pets Allowed:
      <select name=pet value='pet'>
        <option >Yes</option>
        <option >No</option>
      </select>
      Bedroom:
      <select name=bedNum value='bedNum'>
        <option placeholder="1+">1</option>
        <option placeholder="2+">2</option>
        <option placeholder="3+">3</option>
        <option placeholder="4+">4</option>
        <option placeholder="5+">5</option>
      </select>
      Bathroom:
      <select name=bathNum value='bathNum'>
        <option placeholder="1+">1</option>
        <option placeholder="2+">2</option>
        <option placeholder="3+">3</option>
        <option placeholder="4+">4</option>
        <option placeholder="5+">5</option>
      </select>
      <br>
      <br>
      <label class="number-inline">Min: <input type="number" name="min" placeholder="1000"></label>
      <label class="number-inline">Max: <input type="number" name="max" placeholder="100000"></label>

      <button type="submit" name="submitFilter" class="btn btn-primary btn-sm">Filter</button>


    </div>
  </form>
  <br>
  <br>
  <form method="post"  action="selectedProperty.php">
    <div class="container">
      <div class="row" id="result">
        <?php
        while($row =$search_result->fetch_assoc()){
          ?>
          <div class="col-sm-3" >
            <div class="card-deck" >
              <div class="card-body-secondary">
                <img src="../img/<?= $row['imageProp']?>" class="card-img-top" style="height:190px; width:190px">
                <div class="card-img">
                  <h6 style="margin-top:10px;" class="text-light bg-info text-center rounded p-1">
                    <?= $row['agentUsername']; ?>
                  </h6>
                </div>

                <div class="card-body">
                  <h4 class="card-title text-danger">Price
                    : <?= number_format($row['pdPrice']); ?>
                  </h4>
                  <p>
                    Province : <?= $row['provinceName']; ?><br>
                    City : <?= $row['cityName']; ?><br>
                  </p>
                  <p>
                    Bedrooms : <?= $row['pdBedroomCount']; ?><br>
                    Bathrooms : <?= $row['pdBathroomCount']; ?><br>
                    Garage : <?= $row['pdParkingNum']; ?><br>
                    <?php $propertyNum = $row['propertyNo'];
                    echo "Property number is ". $row['propertyNo'] . ".";
                    ?>
                    <input type="hidden" name="numProp"  value="<?php echo$row['propertyNo'];?>">
                    <div class="input-group">
                      <a href="selectedProperty.php?data=<?=$propertyNum?>">Bring me to nextPage</a>
                      <button type="submit" name="seleProp" class="btn btn-primary btn-sm" >Rent Property</button>
                    </div>
                  </p>
                </div>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>
    <?php
    if (isset($_POST['seleProp'])){
          $_SESSION['propNumber'] = $_POST['numProp'];
          header('location: selectedProperty.php');
      }
     ?>
  </form>
</body>
</html>

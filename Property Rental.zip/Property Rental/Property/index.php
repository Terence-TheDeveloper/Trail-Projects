<?php
  session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title> Property Rental </title>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <!-- Popper JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

  <!-- Latest compiled JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</head>
<body>

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="#"><img alt="Logo" src="img/logo.png" height="50px"></a>

  <!-- Links -->
  <ul class="navbar-nav">
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Agent
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="agent/registration/login.php">Login</a>
        <a class="dropdown-item" href="agent/registration/register.php">Sign up</a>
      </div>
    </li>
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Tenant
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="tenant/registration/login.php">Login</a>
        <a class="dropdown-item" href="tenant/registration/register.php">Sign up</a>
      </div>
    </li>
  </ul>
</nav>



</body>
</html>

-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2021 at 02:01 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rentaldatabase`
--

-- --------------------------------------------------------
DROP DATABASE IF EXISTS rentaldatabase;
CREATE DATABASE rentaldatabase;
USE 'rentaldatabase';
--
-- Table structure for table `agent`
--

CREATE TABLE `agent` (
  `agentUsername` varchar(100) NOT NULL,
  `agentFname` varchar(15) NOT NULL,
  `agentLname` varchar(15) NOT NULL,
  `agentCellPhone` varchar(11) NOT NULL DEFAULT '0',
  `agentCity` varchar(20) NOT NULL,
  `agentProvince` varchar(20) NOT NULL,
  `agentStreetName` varchar(20) NOT NULL,
  `agentStreetNum` int(5) NOT NULL,
  `agentCompanyName` varchar(20) NOT NULL,
  `agentPassword` varchar(32) NOT NULL,
  `agentEmail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agent`
--

INSERT INTO `agent` (`agentUsername`, `agentFname`, `agentLname`, `agentCellPhone`, `agentCity`, `agentProvince`, `agentStreetName`, `agentStreetNum`, `agentCompanyName`, `agentPassword`, `agentEmail`) VALUES
('CompaLit', 'Ayanda', 'Mabuza', '0789894664', 'Bloemfontein', 'Free State', 'Rahisa', 35, 'Housing For You', '72cdccb8e23434738350dea822cb8587', 'dfghfui@gmail.com'),
('Duty', 'Flix', 'Gate', '0785946523', 'Cape Town', 'Western Cape', 'Glory', 18, 'Gilmore Rent', '7ad772ab04ae9ea806dc664f87a93d86', 'glory.rent@gmail.com'),
('Foell', 'Atwell', 'Fox', '0785894636', 'Johannesburgy', 'Gauteng', 'Voka', 73, 'Rentkaal', '46bf36a7193438f81fccc9c4bcc8343e', 'Atwell@gmail.com'),
('Freefree22', 'Njabulo', 'Maphenduka', '0726946364', 'Mossel Bay', 'Western Cape', 'Hook', 18, 'Kellyhills Property', '26e255edffbc569d2d3a61f3930fb442', 'hmdhfui@gmail.com'),
('HeadWay35', 'Ngoni', 'Bepe', '0711259467', 'East London', 'Eastern Cape', 'Voosa', 375, 'M Homes', 'd01aa78e43edaac2c8a0218f6fa401c8', 'tyri@gmail.com'),
('HouseWay', 'Sibusio', 'Mabuza', '0794667568', 'Ermelo', 'Mpumalanga', 'Rahisa', 34, 'Africa Rent', 'a7eab2924a827432d47fd2d813089a92', 'puyhfui@gmail.com'),
('JamHouse', 'Adam', 'Smith', '0689466985', 'Upington', 'Northen Cape', 'Desmon', 784, 'James Housing', '6d44bae9b292519844cad0a9a62e1eaf', 'kjtfui@gmail.com'),
('Kaden', 'Lark', 'Madden', '0785894636', 'Ermelo', 'Mpumalanga', 'Larka', 27, 'Rental East State', '46bf36a7193438f81fccc9c4bcc8343e', 'Lark@gmail.com'),
('Karix', 'Kai', 'Hendrix', '0794632236', 'Johannesburgy', 'Gauteng', 'Hendria', 23, 'Voka Rental', '46bf36a7193438f81fccc9c4bcc8343e', 'Kai@gmail.com'),
('Keat', 'Lake', 'Katz', '0785946236', 'Cape Town', 'Western Cape', 'Lake', 27, 'Rentokaal', '46bf36a7193438f81fccc9c4bcc8343e', 'Lake@gmail.com'),
('Leo', 'Leo', 'Votjeka', '0755494663', 'Witbank', 'Mpumalanga', 'Cherk Road', 4, 'My Rental', '312f91285e048e09bb4aefef23627994', 'leo.votjeka@gmail.com'),
('Liart', 'Dahlia', 'Hart', '0785839466', 'Johannesburgy', 'Gauteng', 'Vhliaa', 73, 'Voka Rental', '46bf36a7193438f81fccc9c4bcc8343e', 'Dahlia@gmail.com'),
('LitHousing', 'Privilege', 'Masvanise', '0795946652', 'Johannesburgy', 'Gauteng', 'Rahia', 274, 'Homes Lit', '08fe02d416430341fec73bad26a21ae4', 'fsrhfui@gmail.com'),
('Myway', 'Charity', 'Mwelase', '0719465248', 'Johannesburgy', 'Gauteng', 'Moosa', 652, 'T Homes', 'e96ad7d3a8ee6b14c28724163e7cfe42', 'vxui@gmail.com'),
('Necis', 'Crane', 'Francis', '0789462236', 'Ermelo', 'Mpumalanga', 'Craka', 273, 'Voal', '46bf36a7193438f81fccc9c4bcc8343e', 'Crane@gmail.com'),
('Poai', 'Posy', 'Sai', '0789462236', 'Johannesburgy', 'Gauteng', 'Poka', 237, 'United Rental', '46bf36a7193438f81fccc9c4bcc8343e', 'Posy@gmail.com'),
('Rent', 'Jabavu', 'Zwane', '0785946236', 'Cape Town', 'Western Cape', 'Hima', 98, 'Property Rent', 'e3d0f9c78de617034b519c6ac4996026', 'sfetdhfui@gmail.com'),
('Sanreal', 'Vasant', 'Villarreal', '0789462236', 'Ermelo', 'Mpumalanga', 'Renrea', 73, 'AHCD Rental', '46bf36a7193438f81fccc9c4bcc8343e', 'Vasant@gmail.com'),
('test', 'Terence', 'Musa', '  071738506', 'Ermelo', 'Mpumalanga', '  John Vorster', 26, 'Vorster Rental Int', '202cb962ac59075b964b07152d234b70', 'test.musa.dlamini@gmail.com'),
('Verick', 'Weaver', 'Frederick', '0785946236', 'Johannesburgy', 'Gauteng', 'Weava', 23, 'Voktal', '46bf36a7193438f81fccc9c4bcc8343e', 'Weaver@gmail.com'),
('Yaca', 'Aya', 'Caddel', '0894674436', 'Ermelo', 'Mpumalanga', 'Fran', 73, 'Voka Rental', '46bf36a7193438f81fccc9c4bcc8343e', 'Aya@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `citylookup`
--

CREATE TABLE `citylookup` (
  `cityId` int(100) NOT NULL,
  `provinceId` int(100) NOT NULL,
  `cityName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `citylookup`
--

INSERT INTO `citylookup` (`cityId`, `provinceId`, `cityName`) VALUES
(1, 6, 'Witbank'),
(2, 9, 'Cape Town'),
(3, 6, 'Ermelo'),
(4, 4, 'Durban'),
(5, 3, 'Johannesburg'),
(6, 2, 'East London'),
(7, 2, 'Kimberley'),
(8, 8, 'Mossel Bay'),
(9, 6, 'Upington'),
(10, 5, 'Polokwane');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `propertyNo` int(100) NOT NULL,
  `agentUsername` varchar(100) NOT NULL,
  `provinceId` int(200) NOT NULL,
  `cityId` int(200) NOT NULL,
  `propertyName` varchar(100) NOT NULL DEFAULT 'Not Named',
  `propStreetAddress` varchar(200) NOT NULL,
  `propType` varchar(200) NOT NULL,
  `propListingDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`propertyNo`, `agentUsername`, `provinceId`, `cityId`, `propertyName`, `propStreetAddress`, `propType`, `propListingDate`) VALUES
(1, 'HouseWay', 9, 2, 'Not Named', '54 Forest Road', 'Apartment', '2020-05-25'),
(2, 'Rent', 6, 3, 'Not Named', '27 Lake Road', 'House', '2019-06-04'),
(3, 'Rent', 2, 7, 'Not Named', '27 Road', 'House', '2019-06-05'),
(4, 'headWay35', 5, 10, 'Not Named', '64 Ocean Road', 'Apartment', '2020-07-03'),
(5, 'LitHousing', 2, 7, 'Not Named', '85 Paker Road', 'Commercial', '2020-04-17'),
(6, 'Sanreal', 2, 6, 'Not Named', '85 Paad', 'Commercial', '2020-04-19'),
(7, 'HouseWay', 2, 6, 'Not Named', '67 Forest Road', 'Apartment', '2021-01-04'),
(8, 'Rent', 4, 4, 'Not Named', '2 Lake Road', 'House', '2020-07-26'),
(9, 'headWay35', 6, 9, 'Not Named', '4 Ock Road', 'Apartment', '2020-11-07'),
(10, 'Karix', 6, 3, 'Not Named', '30 Heardewyk', 'House', '2020-05-25'),
(11, 'Yaca', 6, 3, 'Not Named', '64 Odfad', 'Apartment', '2020-10-13'),
(12, 'test', 6, 9, 'Not Named', '345 Odfad', 'Apartment', '2020-01-13'),
(13, 'Rent', 3, 5, 'Not Named', '36 Ocdsad', 'House', '2020-10-13'),
(14, 'test', 8, 8, 'Not Named', '4 Bcad', 'Commercial', '2020-09-13'),
(15, 'test', 3, 5, 'Not Named', '47 Ocsszad', 'House', '2020-07-13'),
(16, 'Keat', 6, 1, 'Not Named', '36 Ocbhad', 'Apartment', '2021-01-13'),
(17, 'Foell', 5, 10, 'Not Named', '2 Ocasfdd', 'Apartment', '2019-11-13'),
(18, 'test', 6, 1, 'Not Named', '74 Ocadd', 'House', '2019-11-13'),
(19, 'Foell', 9, 2, 'Not Named', '86 Ocsddad', 'Commercial', '2021-02-13');

-- --------------------------------------------------------

--
-- Table structure for table `propertydetails`
--

CREATE TABLE `propertydetails` (
  `pdListingNumber` int(100) NOT NULL,
  `propertyNo` int(100) NOT NULL,
  `pdBedroomCount` int(100) NOT NULL DEFAULT 0,
  `pdBathroomCount` int(100) NOT NULL DEFAULT 0,
  `pdPetAllowed` varchar(3) NOT NULL DEFAULT 'No',
  `pdParkingNum` int(2) NOT NULL DEFAULT 0,
  `pdLeasePeriod` int(20) NOT NULL DEFAULT 6,
  `pdFurnished` varchar(10) NOT NULL DEFAULT 'No',
  `pdDescription` text DEFAULT NULL,
  `pdPrice` int(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `propertydetails`
--

INSERT INTO `propertydetails` (`pdListingNumber`, `propertyNo`, `pdBedroomCount`, `pdBathroomCount`, `pdPetAllowed`, `pdParkingNum`, `pdLeasePeriod`, `pdFurnished`, `pdDescription`, `pdPrice`) VALUES
(1, 1, 2, 1, 'No', 1, 12, 'Yes', 'Home sweet home 1', 4500),
(2, 2, 2, 1, 'No', 1, 12, 'No', 'Home sweet home 2', 5000),
(3, 3, 3, 1, 'Yes', 1, 12, 'Yes', 'Home sweet home 3', 7800),
(4, 4, 4, 2, 'Yes', 2, 6, 'No', 'Home sweet home 4', 12300),
(5, 5, 2, 1, 'No', 0, 12, 'No', 'Home sweet home 5', 4500),
(6, 6, 3, 2, 'Yes', 1, 12, 'Yes', 'Home sweet home 6', 10800),
(7, 7, 4, 2, 'Yes', 2, 6, 'Yes', 'Home sweet home 7', 13250),
(8, 8, 6, 3, 'No', 2, 12, 'Yes', 'Home sweet home 8', 14500),
(9, 9, 4, 3, 'No', 2, 12, 'No', 'Home sweet home 9', 8000),
(10, 10, 5, 2, 'Yes', 1, 12, 'Yes', 'Home sweet home 10', 9800),
(11, 11, 5, 3, 'Yes', 3, 6, 'No', 'Home sweet home 11', 12300),
(12, 12, 2, 1, 'No', 0, 12, 'No', 'Home sweet home 12', 4000),
(13, 13, 3, 2, 'Yes', 1, 12, 'Yes', 'Home sweet home 13', 6400),
(14, 14, 4, 2, 'Yes', 2, 6, 'Yes', 'Home sweet home 14', 9250),
(15, 15, 2, 1, 'No', 0, 12, 'No', 'Home sweet home 15', 5600),
(16, 16, 3, 1, 'Yes', 1, 12, 'Yes', 'Home sweet home 16', 7800),
(17, 17, 4, 2, 'Yes', 3, 6, 'Yes', 'Home sweet home 17', 14500),
(18, 18, 2, 1, 'No', 0, 12, 'Yes', 'Home sweet home 18', 3500),
(19, 19, 2, 1, 'No', 0, 12, 'No', 'Home sweet home 19', 3200);

-- --------------------------------------------------------

--
-- Table structure for table `propertypicture`
--

CREATE TABLE `propertypicture` (
  `imageId` int(100) NOT NULL,
  `propertyNo` int(100) NOT NULL,
  `imageProp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `propertypicture`
--

INSERT INTO `propertypicture` (`imageId`, `propertyNo`, `imageProp`) VALUES
(1, 1, 'home 1.png'),
(2, 2, 'home 2.png'),
(3, 3, 'home 3.png'),
(4, 4, 'home 4.png'),
(5, 5, 'home 5.png'),
(6, 6, 'home 6.png'),
(7, 7, 'home 7.png'),
(8, 8, 'home 8.png'),
(9, 9, 'home 9.png'),
(10, 10, 'home 10.png'),
(11, 11, 'home 11.png'),
(12, 12, 'home 12.png'),
(13, 13, 'home 13.png'),
(14, 14, 'home 14.png'),
(15, 15, 'home 15.png'),
(16, 16, 'home 16.png'),
(17, 17, 'home 17.png'),
(18, 18, 'home 18.png'),
(19, 19, 'home 19.png');

-- --------------------------------------------------------

--
-- Table structure for table `provincelookup`
--

CREATE TABLE `provincelookup` (
  `provinceId` int(100) NOT NULL,
  `provinceName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provincelookup`
--

INSERT INTO `provincelookup` (`provinceId`, `provinceName`) VALUES
(1, 'Eastern Cape'),
(2, 'Free State'),
(3, 'Gauteng'),
(4, 'KwaZulu-Natal'),
(5, 'Limpopo'),
(6, 'Mpumalanga'),
(7, 'Northern Cape'),
(8, 'North-West'),
(9, 'Western Cape');

-- --------------------------------------------------------

--
-- Table structure for table `tenant`
--

CREATE TABLE `tenant` (
  `tenantUsername` varchar(100) NOT NULL,
  `tenantFname` varchar(100) NOT NULL,
  `tenantLname` varchar(100) NOT NULL,
  `tenantEmail` varchar(100) NOT NULL,
  `tenantPassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tenant`
--

INSERT INTO `tenant` (`tenantUsername`, `tenantFname`, `tenantLname`, `tenantEmail`, `tenantPassword`) VALUES
('AlexSweet', 'Alex', 'Peele', 'Alex@gmail.com', 'bb70bc777e12830861ab21ee0897727d'),
('BlakeDragon', 'Blake', 'Lively', 'Blakee@gmail.com', 'bb70bc777e12830861ab21ee0897727d'),
('Capt', 'Sile', 'Geek', 'dan@gmail.com', '9833c6550489cfec2ba619c78c8ecc6b'),
('Captain', 'Dansile', 'Smith', 'dansile@gmail.com', '22998e745670cfa744de97474c9bc6c2'),
('Dam', 'Daim', 'Dan', 'dam@gmail.com', '52b78f112d1e1c12fa8b0296b718b180'),
('Danrks', 'Jordan', 'Sparks', 'Jordan@gmail.com', 'bb70bc777e12830861ab21ee0897727d'),
('Freedomfighter', 'Nisha', 'Brown', 'nisha@gmail.com', '078637ba5dd228097fb19156bfbd0a9d'),
('Freeter', 'Waha', 'Gilmore', 'nwha@gmail.com', '3ab0e3a501c376968fc66f2ed2b138f1'),
('Huren', 'Lesego', 'Davis', 'lesego@gmail.com', '1a29899d80f0d8a73b78d7da12b25102'),
('JamesBond77', 'James', 'Jim', 'Jamese@gmail.com', 'bb70bc777e12830861ab21ee0897727d'),
('Leill', 'Kyle', 'Hills', 'Kyle@gmail.com', 'bb70bc777e12830861ab21ee0897727d'),
('Lormore', 'Taylor', 'Barrymore', 'Taylor@gmail.com', 'bb70bc777e12830861ab21ee0897727d'),
('Madam', 'Sidi', 'Jones', 'sidi@gmail.com', '6123a6aaaaa38d811da698ff5952ec94'),
('Mars22', 'Harry', 'Williams', 'harry@gmail.com', '37795ebfd3185cf890a21679bfddd6e2'),
('Marshall', 'Terence', 'Dlamini', 'terence@gmail.com', '0731e19c412ab193b3353955bc56542a'),
('Nedrong', 'Kennedy', 'Strong', 'Kennedy@gmail.com', 'bb70bc777e12830861ab21ee0897727d'),
('Reey', 'Drew', 'Carey', 'Drew@gmail.com', 'bb70bc777e12830861ab21ee0897727d'),
('RenLord', 'Sego', 'Count', 'sego@gmail.com', '194cc88d7fa71c5c64947eb72a4ded8a'),
('Roniaz', 'Cameron', 'Diaz', 'Cameron@gmail.com', 'bb70bc777e12830861ab21ee0897727d'),
('test', 'Spy', 'Dlamini', 'test.musa.dlamini@gmail.com', '202cb962ac59075b964b07152d234b70'),
('Verker', 'Avery', 'Decker', 'Averye@gmail.com', 'bb70bc777e12830861ab21ee0897727d');

-- --------------------------------------------------------

--
-- Table structure for table `tenantproperty`
--

CREATE TABLE `tenantproperty` (
  `tenantPropId` int(100) NOT NULL,
  `tenantUsername` varchar(100) NOT NULL,
  `propertyNo` int(100) NOT NULL,
  `tpOccupationDate` date NOT NULL,
  `tpLeaveDate` date DEFAULT NULL,
  `tpRentalPrice` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tenantproperty`
--

INSERT INTO `tenantproperty` (`tenantPropId`, `tenantUsername`, `propertyNo`, `tpOccupationDate`, `tpLeaveDate`, `tpRentalPrice`) VALUES
(1, 'Madam', 1, '2021-01-23', '2022-01-23', 12454),
(2, 'test', 2, '2021-01-06', '2022-01-06', 10454),
(3, 'Mars22', 4, '2021-02-23', '2022-01-23', 12454),
(4, 'test', 7, '2020-09-06', '2022-01-06', 10454),
(5, 'Huren', 8, '2020-11-23', '2022-01-23', 12454),
(6, 'Danrks', 9, '2021-03-06', '2022-03-06', 10454),
(7, 'Reey', 15, '2021-02-23', '2022-02-23', 12454),
(8, 'test', 12, '2021-03-16', '2022-03-16', 10454),
(9, 'Roniaz', 17, '2021-04-23', '2022-04-23', 12454),
(14, 'Marshall', 3, '2021-03-04', '2021-03-12', 15000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agent`
--
ALTER TABLE `agent`
  ADD PRIMARY KEY (`agentUsername`);

--
-- Indexes for table `citylookup`
--
ALTER TABLE `citylookup`
  ADD PRIMARY KEY (`cityId`),
  ADD KEY `fk_provincelookup_id` (`provinceId`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`propertyNo`),
  ADD KEY `fk_province_id` (`provinceId`),
  ADD KEY `fk_city_id` (`cityId`),
  ADD KEY `fk_username` (`agentUsername`);

--
-- Indexes for table `propertydetails`
--
ALTER TABLE `propertydetails`
  ADD PRIMARY KEY (`pdListingNumber`),
  ADD KEY `fk_property_No` (`propertyNo`);

--
-- Indexes for table `propertypicture`
--
ALTER TABLE `propertypicture`
  ADD PRIMARY KEY (`imageId`),
  ADD KEY `fk_propertyPic_No` (`propertyNo`);

--
-- Indexes for table `provincelookup`
--
ALTER TABLE `provincelookup`
  ADD PRIMARY KEY (`provinceId`);

--
-- Indexes for table `tenant`
--
ALTER TABLE `tenant`
  ADD PRIMARY KEY (`tenantUsername`);

--
-- Indexes for table `tenantproperty`
--
ALTER TABLE `tenantproperty`
  ADD PRIMARY KEY (`tenantPropId`),
  ADD KEY `fk_tenantproperty_No` (`propertyNo`),
  ADD KEY `fk_tenant_username` (`tenantUsername`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `citylookup`
--
ALTER TABLE `citylookup`
  MODIFY `cityId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `propertyNo` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `propertydetails`
--
ALTER TABLE `propertydetails`
  MODIFY `pdListingNumber` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `propertypicture`
--
ALTER TABLE `propertypicture`
  MODIFY `imageId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tenantproperty`
--
ALTER TABLE `tenantproperty`
  MODIFY `tenantPropId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `citylookup`
--
ALTER TABLE `citylookup`
  ADD CONSTRAINT `fk_provincelookup_id` FOREIGN KEY (`provinceId`) REFERENCES `provincelookup` (`provinceId`);

--
-- Constraints for table `property`
--
ALTER TABLE `property`
  ADD CONSTRAINT `fk_city_id` FOREIGN KEY (`cityId`) REFERENCES `citylookup` (`cityId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_province_id` FOREIGN KEY (`provinceId`) REFERENCES `provincelookup` (`provinceId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_username` FOREIGN KEY (`agentUsername`) REFERENCES `agent` (`agentUsername`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `propertydetails`
--
ALTER TABLE `propertydetails`
  ADD CONSTRAINT `fk_property_No` FOREIGN KEY (`propertyNo`) REFERENCES `property` (`propertyNo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `propertypicture`
--
ALTER TABLE `propertypicture`
  ADD CONSTRAINT `fk_propertyPic_No` FOREIGN KEY (`propertyNo`) REFERENCES `property` (`propertyNo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tenantproperty`
--
ALTER TABLE `tenantproperty`
  ADD CONSTRAINT `fk_tenant_username` FOREIGN KEY (`tenantUsername`) REFERENCES `tenant` (`tenantUsername`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tenantproperty_No` FOREIGN KEY (`propertyNo`) REFERENCES `property` (`propertyNo`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php include ('header.php');

$id = $_SESSION['username'];
$query= "SELECT * FROM agent where agentUsername='$id'";
$result= mysqli_query($conn,$query);
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <title>Update</title>
    <meta charset="utf-8">
    <style>
    </style>
  </head>
  <body>
    <center>
      <h1>Agent Profile</h1>

      <form action="" method="POST">
        <label>Username</label>
        <input type="text" name="agentUsername" placeholder="<?php echo $row['agentUsername']; ?>" value="<?php echo $row['agentUsername']; ?>" readonly/><br/>
        <label>Firstname</label>
        <input type="text" name="agentFname" placeholder="<?php echo $row['agentFname']; ?>" value="<?php echo $row['agentFname']; ?>" readonly/><br/>
        <label>Lastname</label>
        <input type="text" name="agentLname" placeholder="<?php echo $row['agentLname']; ?>" value="<?php echo $row['agentLname']; ?>" readonly/><br/>
        <label>Cellphone Number</label>
        <input type="text" name="agentCellPhone" placeholder="<?php echo $row['agentCellPhone']; ?>" value="<?php echo $row['agentCellPhone']; ?>" readonly/><br/>
        <label>City</label>
        <input type="text" name="agentCity" placeholder="<?php echo $row['agentCity']; ?>" value="<?php echo $row['agentCity']; ?>" readonly/><br/>
        <label>Province</label>
        <input type="text" name="agentProvince" placeholder="<?php echo $row['agentProvince']; ?>" value="<?php echo $row['agentProvince']; ?>" readonly/><br/>
        <label>Street Number</label>
        <input type="number" name="agentStreetNum" placeholder="<?php echo $row['agentStreetNum']; ?>" value="<?php echo $row['agentStreetNum']; ?>" readonly/><br/>
        <label>Street Name</label>
        <input type="text" name="agentStreetName" placeholder="<?php echo $row['agentStreetName']; ?>" value="<?php echo $row['agentStreetName']; ?>" readonly/><br/>
        <label>Company Name</label>
        <input type="text" name="agentCompanyName" placeholder="<?php echo $row['agentCompanyName']; ?>" value="<?php echo $row['agentCompanyName']; ?>" readonly/><br/>
        <label>Password</label>
        <input type="password" name="agentPassword" placeholder="<?php echo $row['agentPassword']; ?>"  value="<?php echo $row['agentPassword']; ?>" readonly/><br/>
        <label>Email</label>
        <input type="email" name="agentEmail" placeholder="<?php echo $row['agentEmail']; ?>" value="<?php echo $row['agentEmail']; ?>" readonly/><br/>

      <input type="submit" name="update" value="Edit Profile"/>
    </center>
  </body>
</html>

<?php
 if (isset($_POST['update']))
 {
     header('location: updateAgentInfoProccess.php');

 }
 ?>

<?php include ('header.php');

if (isset($_POST['submitProp']))
{

  $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];
        $folder = "../img/".$filename;
        // Get all the submitted data from the form
        $propMAX = mysqli_query($conn,"SELECT MAX(propertyNo) as propNum FROM property");
        $maxRow=mysqli_fetch_array($propMAX);
        $max = $maxRow['propNum'];
        $sql = "INSERT INTO propertypicture (propertyNo, imageProp) VALUES ('$max','$filename')";
        // Execute query
        mysqli_query($conn, $sql);
        // Now let's move the uploaded image into the folder: image
        if (move_uploaded_file($tempname, $folder))  {
            $msg = "Image uploaded successfully";
        }else{
            $msg = "Failed to upload image";
      }

  $listingDate = date("Y-m-d");
  $provinceID = $_POST["provinceLookup"];
  $city = $_POST["cityLookup"];
  $propName = $_POST["propName"];
  $streetAddress = $_POST["streetAddress"];
  $propType = $_POST["propType"];
  $numBedroom = $_POST["numBedroom"];
  $numBathroom = $_POST["numBathroom"];
  $pets = $_POST["pYesOrNo"];
  $parking = $_POST["numParking"];
  $leasePeriod = $_POST["numPeriod"];
  $furnished = $_POST["fYesOrNo"];
  $description = $_POST["description"];
  $price = $_POST["price"];

  $addProperty = "INSERT INTO property (agentUsername, provinceId, cityId, propertyName, propStreetAddress, propType, propListingDate)
  VALUES ('$sessionUser', '$provinceID' , '$city', '$propName', '$streetAddress', '$propType', '$listingDate')";
  mysqli_query($conn, $addProperty);

  $addPropDetails = "INSERT INTO propertydetails (propertyNo, pdBedroomCount, pdBathroomCount, pdPetAllowed, pdParkingNum, pdLeasePeriod, pdFurnished, pdDescription, pdPrice)
  VALUES ('$max','$numBedroom', '$numBathroom', '$pets', '$parking', '$leasePeriod', '$furnished', '$description', '$price')";
  mysqli_query($conn, $addPropDetails);

  header('location: listproperties.php');

}


 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <title>Add Property</title>
    <meta charset="utf-8">
    <style>
    </style>
  </head>
  <body>
    <br>
    <br>
    <form class="" action="#" method="post" enctype="multipart/form-data">
      <div class="container">
        <div id="content">
            <input type="file" name="uploadfile" value="" />
          </div>
        <br>
        Province: <br>
        <?php
        $province="SELECT provinceId, provinceName FROM provinceLookup order by provinceName";
        /* You can add order by clause to the sql statement if the names are to be displayed in alphabetical order */
        echo "<select name = provinceLookup>Province Names</option>"; // list box select command

        foreach ($conn->query($province) as $row){//Array or records stored in $row

          echo "<option value=$row[provinceId]> $row[provinceName]</option>";
          /* Option values are added by looping through the array */
        }
        echo "</select>";// Closing of list box
        ?>
        <br>
        <br>
        City:<br>
        <?php
        $cityInfo="SELECT cityId, cityName FROM citylookup order by cityName";
        /* You can add order by clause to the sql statement if the names are to be displayed in alphabetical order */
        echo "<select name = cityLookup>City Names</option>"; // list box select command

        foreach ($conn->query($cityInfo) as $row){//Array or records stored in $row

          echo "<option value=$row[cityId]> $row[cityName]</option>";
          /* Option values are added by looping through the array */
        }
        echo "</select>";// Closing of list box
        ?>
        <br><br>
        Property Name:<br> <input type="text" name="propName" required>
        <br><br>
        Street Address:<br> <input type="text" name="streetAddress" required>
        <br><br>

        Property Type:<br>
        <input type="radio" name="propType" value="Apartment" > Apartment
        <input type="radio" name="propType" value="House"> House
        <input type="radio" name="propType" value="Commercial"> Commercial
        <input type="radio" name="propType" value="Development"> Development

        <br><br>
        Number of Bedroom:<br><input type="number" name="numBedroom" required>
        <br><br>
        Number of Bathroom:<br> <input type="number" name="numBathroom" required>
        <br><br>
        Number of Parking:<br> <input type="number" name="numParking" required>
        <br><br>
        Pets Allowed:<br>
        <input type="radio" name="pYesOrNo" value="Yes"> Yes
        <input type="radio" name="pYesOrNo" value="No"> No
        <br><br>
        Lease Period:<br><input type="number" name="numPeriod" required>
        <br><br>
        Furnished:
        <input type="radio" name="fYesOrNo" value="Yes"> Yes
        <input type="radio" name="fYesOrNo" value="No"> No
        <br><br>
        Description:<br> <textarea name="description" rows="5" cols="40" required></textarea>
        <br><br>
        Price:<br> <input type="number" name="price" required>
        <br><br>

        <button type="submit" name="submitProp" class="btn btn-primary btn-sm">Add Property</button>
          <a href="listproperties.php">
            <button type="button" class="btn btn-primary btn-sm ">Cancel</button>
          </a>
          <br>
          <br>
      </div>

    </form>

  </body>
</html>

<?php
  session_start();
  include ('../connect.php');

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: registration/login.php');
  }

  $sessionUser=$_SESSION['username'];
  $res=mysqli_query($conn, "SELECT * FROM agent WHERE
  agentUsername ='$sessionUser'");
  $userRow=mysqli_fetch_array($res);


?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8 (Without BOM)">
        <title></title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        <!-- Popper JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    </head>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="#"><img alt="Logo" src="img/logo.png" height="50px"></a>

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="agentProfile.php">My Profile</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="listproperties.php">My Properties</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="rentProperty.php">Rented Properties</a>
    </li>
  </ul>
    <!-- Dropdown -->
    <ul class="nav navbar-nav ml-auto">
      <li class="nav-item dropdown" >
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown"> <?php echo $userRow['agentFname']; ?> <?php echo $userRow['agentLname']; ?>
      </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="agentLogout.php?logout">Logout</a>
        </div>
      </li>
    </ul>
</nav>

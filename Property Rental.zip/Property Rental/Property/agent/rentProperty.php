<?php include ('header.php');
$propCount = mysqli_query($conn,"SELECT COUNT(propertyNo) as propNum FROM property WHERE agentUsername = '$sessionUser'");
$pRow=mysqli_fetch_array($propCount);

$tenantProp = "SELECT p.*, tp.* FROM tenantproperty tp, property p WHERE p.propertyNo = tp.propertyNo AND p.agentUsername = '$sessionUser'";
$prop_result = $conn->query($tenantProp);

if (isset($_POST['leaseProp']))
{
$occupationDateOld = $_POST['occupationDate'];
$leaveDateOld = $_POST['leaveDate'];
$price = $_POST['actualPrice'];
$propNum = $_POST['pNum'];
$tenantusername = $_POST['tUsername'];

$occupationDate = date("Y-m-d", strtotime($occupationDateOld));
$leaveDate = date("Y-m-d", strtotime($leaveDateOld));

$propNo = mysqli_query($conn,"SELECT tp.propertyNo FROM tenantproperty tp, property p
WHERE p.propertyNo = tp.propertyNo AND tp.propertyNo = '$propNum'");
$tProp= mysqli_fetch_array($propNo);

$propUser = mysqli_query($conn,"SELECT tenantUsername FROM tenant
WHERE tenantUsername = '$tenantusername'");
$tUser=mysqli_fetch_array($propUser);

if ($tProp){ // if user exists
      echo '<script type="text/javaScript"> alert("Property Already Leased") </script>';
    }
  else if ($tUser) {
      $leaseP = "INSERT INTO tenantproperty (tenantUsername, propertyNo, tpOccupationDate, tpLeaveDate, tpRentalPrice)
      VALUES ('$tenantusername', '$propNum' , '$occupationDate', '$leaveDate', '$price')";
      $query_run = mysqli_query($conn, $leaseP);
      echo '<script type="text/javaScript"> alert("Property Leased") </script>';
      header('location: rentProperty.php');
    }
    else {
      echo '<script type="text/javaScript"> alert("Username Does Not Exist") </script>';
    }

}


?>
<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>
  <div class="container-fluid">
    <h1>Lease a Property
    </h1>
    <p>
      You Have <?php echo $pRow['propNum']; ?> Properties
    </p>
    <hr>
  </div>

<form class="container-fluid" method="post">
<div>
    <div class="input jumbotron col" style="width:auto">
      <div class="form-group">
      <label> Occupation Date </label><br>
      <input type="date"  name="occupationDate">
      </div>
      <div class="form-group">
      <label> Leave Date </label><br>
      <input type="date" name="leaveDate">
      </div>
      <div class="form-group">
      <label> Price </label><br>
      <input type="number" name="actualPrice">
      </div>
      <div class="form-group">
      <label> Property Number </label><br>
      <input type="number" name="pNum">
      </div>
      <div class="form-group">
      <label> Tenant Username </label><br>
      <input type="text" name="tUsername">
      </div>
      <div class="form-group">
      <button type="submit" name="leaseProp" class="btn btn-primary btn-sm">Lease</button>
      </div>
    </div>
</div>
<div class="container text-right mb-1" >
  <button type="submit" name="rLeaseBtn" class="btn btn-primary btn-sm">Remove</button>
</div>
<br>
<?php
while($pRow = $prop_result->fetch_assoc()){
  ?>
  <div class="container">
    <table class="table">
        <thead class="thead-dark">
          <tr>
            <th>#</th>
            <th>Tenant Property Number</th>
            <th>Tenant Username</th>
            <th>Property Number</th>
            <th>Occupation Date</th>
            <th>Leave Date</th>
            <th>Actual Price</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
            <input type="checkbox" name="removeLease" value="<?php echo $pRow['tenantPropId'];?>">
          </td>
            <td><?php echo $pRow['tenantPropId'];?></td>
            <td><?php echo $pRow['tenantUsername'];?></td>
            <td><?php echo $pRow['propertyNo']; ?></td>
            <td><?php echo $pRow['tpOccupationDate']; ?></td>
            <td><?php echo $pRow['tpLeaveDate']; ?></td>
            <td><?php echo $pRow['tpRentalPrice']; ?></td>
          </tr>
          <?php
          if (isset($_POST['rLeaseBtn'])){
                $tpropNo = $_POST['removeLease'];
                $query = "DELETE FROM tenantproperty WHERE tenantPropId ='$tpropNo'";
                $result=mysqli_query($conn,$query);

                if ($result) {
                  echo '<script type="text/javaScript"> alert("Property Remove") </script>';
                  header('location: rentProperty.php');
                }
                else
                {
                   echo '<script type="text/javaScript"> alert("Failed to Remove Property") </script>';
                }
            }
           ?>
        </tbody>
    </table>
  </div>
<?php } ?>
<br>
<br>
<br>
</form>
</body>
</html>

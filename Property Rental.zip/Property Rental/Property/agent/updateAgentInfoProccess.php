<?php
include ('header.php');
$id = $_SESSION['username'];
$query= "SELECT * FROM agent where agentUsername='$id'";
$result= mysqli_query($conn,$query);
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <title>Update</title>
    <meta charset="utf-8">
    <style>
    </style>
  </head>
  <body>
    <center>
      <h1>UPDATE  AGENT  INFO</h1>

      <form action="" method="POST">
        <label>Username</label>
        <input type="text" name="agentUsername" placeholder="<?php echo $row['agentUsername']; ?>" value="<?php echo $row['agentUsername']; ?>" readonly/><br/>
        <label>Firstname</label>
        <input type="text" name="agentFname" placeholder="<?php echo $row['agentFname']; ?>" value="<?php echo $row['agentFname']; ?>" /><br/>
        <label>Lastname</label>
        <input type="text" name="agentLname" placeholder="<?php echo $row['agentLname']; ?>" value="<?php echo $row['agentLname']; ?>" /><br/>
        <label>Cellphone Number</label>
        <input type="text" name="agentCellPhone" placeholder="<?php echo $row['agentCellPhone']; ?>" value="<?php echo $row['agentCellPhone']; ?>"/><br/>
        <label>City</label>
        <input type="text" name="agentCity" placeholder="<?php echo $row['agentCity']; ?>" value="<?php echo $row['agentCity']; ?>"/><br/>
        <label>Province</label>
        <input type="text" name="agentProvince" placeholder="<?php echo $row['agentProvince']; ?>" value="<?php echo $row['agentProvince']; ?>"/><br/>
        <label>Street Number</label>
        <input type="number" name="agentStreetNum" placeholder="<?php echo $row['agentStreetNum']; ?>" value="<?php echo $row['agentStreetNum']; ?>" /><br/>
        <label>Street Name</label>
        <input type="text" name="agentStreetName" placeholder="<?php echo $row['agentStreetName']; ?>" value="<?php echo $row['agentStreetName']; ?>"/><br/>
        <label>Company Name</label>
        <input type="text" name="agentCompanyName" placeholder="<?php echo $row['agentCompanyName']; ?>" value="<?php echo $row['agentCompanyName']; ?>"/><br/>
        <label>Password</label>
        <input type="password" name="agentPassword" placeholder="<?php echo $row['agentPassword']; ?>"  value="<?php echo $row['agentPassword']; ?>" readonly/><br/>
        <label>Email</label>
        <input type="email" name="agentEmail" placeholder="<?php echo $row['agentEmail']; ?>" value="<?php echo $row['agentEmail']; ?>" /><br/>

      <input type="submit" name="update" value="Update Profile"/>

      <p> <a href="agentProfile.php" style="color: red;">Cancel</a> </p>
    </center>
  </body>
</html>

<?php
 if (isset($_POST['update']))
 {
   $username = $_POST['agentUsername'];
   $firstanme = $_POST['agentFname'];
   $lastname = $_POST['agentLname'];
   $cellphone = $_POST['agentCellPhone'];
   $city = $_POST['agentCity'];
   $province = $_POST['agentProvince'];
   $streetNum = $_POST['agentStreetNum'];
   $street = $_POST['agentStreetName'];
   $campanyName = $_POST['agentCompanyName'];
   $password = $_POST['agentPassword'];
   $email = $_POST['agentEmail'];

   $query = "UPDATE agent SET agentFname='$firstanme',
   agentLname='$lastname',agentCellPhone=' $cellphone',
   agentCity='$city',agentProvince='$province', agentStreetNum='$streetNum',
   agentStreetName=' $street',agentCompanyName='$campanyName',
   agentPassword='$password',agentEmail='$email'
   WHERE agentUsername= '$id'";

   $query_run = mysqli_query($conn,$query) or die(mysqli_error($conn));

   if ($query_run) {
     echo '<script type="text/javaScript"> alert("Data Updated") </script>';
     header('location: agentProfile.php');
   }
   else
   {
      echo '<script type="text/javaScript"> alert("Data Not Updated") </script>';
   }

 }
 ?>

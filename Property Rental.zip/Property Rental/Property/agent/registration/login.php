<?php include('registerServer.php');
      include('header.php');
 ?>
<!DOCTYPE html>
<html>
<head>
  <title>Agent Login</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Agent Login</h2>
  </div>

  <form method="post" action="login.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Username</label>
  		<input placeholder="Username" type="text" name="username" >
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input placeholder="Password" type="password" name="password">
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
      <button type="submit" class="btn" name="login_tenant">Login as Tenant</button>
  	</div>
  	<p>
  		Not yet a member? <a href="register.php">Sign up</a>
  	</p>
  </form>
</body>
</html>

<?php include ('header.php');

$propCount = mysqli_query($conn,"SELECT COUNT(propertyNo) as propNum FROM property WHERE agentUsername = '$sessionUser'");
$pRow=mysqli_fetch_array($propCount);

$prop = "SELECT * FROM property WHERE agentUsername = '$sessionUser'";
$prop_result = $conn->query($prop);

?>
<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>
<form method="post">

  <div class="container-fluid">
    <h1>My Properties
      <div class="text-right mb-2" >
        <button type="submit" name="deleteProp" class="btn btn-primary btn-sm" >Delete</button>
        <a href="addNewProperty.php">
          <button type="button" class="btn btn-primary btn-sm ">Add Property</button>
        </a>
      </div>
    </h1>
    <p>
      Number of Properties: <?php echo $pRow['propNum']; ?>
    </p>
    <hr>
  </div>

  <?php
  while($pRow = $prop_result->fetch_assoc()){
    ?>
    <div class="container">
      <table class="table">
          <thead class="thead-dark">
            <tr>
              <th>#</th>
              <th>Property Number</th>
              <th>Property Name</th>
              <th>Property Type</th>
              <th>Listing Date</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
              <input type="checkbox" name="propDelete" value="<?php echo $pRow['propertyNo'];?>">
            </td>
              <td><?php echo $pRow['propertyNo'];?></td>
              <td><?php echo $pRow['propertyName'];?></td>
              <td><?php echo $pRow['propType']; ?></td>
              <td><?php echo $pRow['propListingDate']; ?></td>
            </tr>
            <?php
            if (isset($_POST['deleteProp'])){

                  $propNo = $_POST['propDelete'];
                  $query = "DELETE FROM property WHERE propertyNo ='$propNo'";
                  $result=mysqli_query($conn,$query);

                  if ($result) {
                    echo '<script type="text/javaScript"> alert("Property Deleted") </script>';
                    header('location: listproperties.php');
                  }
                  else
                  {
                     echo '<script type="text/javaScript"> alert("Property Not Deleted") </script>';
                  }
              }
             ?>
          </tbody>
      </table>
    </div>
  <?php } ?>
</form>
</body>
</html>

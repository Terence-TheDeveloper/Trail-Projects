Tenant Login
Username: test
Password 123

Agent Login
Username: test
Password 123
-------------------------
PAGES $ ROLES DONE BY:
-------------------------
T.M Dlamini - 216974654

-addNewProperty.php
-agentLogout.php
-listproperties.php
-rentProperties.php
-rentedProperty.php
-invoice.php
-header.php
-errors.php
-login.php
-register.php
-registerServer.php

Role
* Created the database
---------------------------
D.J Jiyane - 216549937

-findProperty.php
-selectedProperty.php
-style.css
-tenantLogout.php
-invoice.css
-index

Role
* Designed the ERD
* Made the page designs
---------------------------
Z.S Masangu - 216367782

-agentProfile.php
-updatedAgentInfoProccess.php
-tenantProfile.php
-updatedTenantInfoProccess.php

Role
* Designed the website pages
* Made the page designs